phpass 
======

**phpass** (pronounced "pH pass") is a portable public domain password hashing framework

https://github.com/hautelook/phpass
